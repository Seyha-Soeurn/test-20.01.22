// uppercase 
function toUpper() {
    document.getElementById("textFieldId1").style.textTransform = "uppercase";
}

// lowercase
function toLower() {
    document.getElementById("textFieldId2").style.textTransform = "lowercase";
}